<?php include("includes/config.php");?>
<!doctype html>

<html class="no-js" lang="en">

<?php include("includes/head-tag.php");?>

<body data-spy="scroll" data-target=".navbar">


    <!--- PRELOADER -->
    <div class="preeloader">
        <div class="preloader-spinner"></div>
    </div>

    <!--SCROLL TO TOP-->
    <!-- <a href="#home" class="scrolltotop"><i class="fa fa-long-arrow-up"></i></a> -->

    <!--START TOP AREA-->
       <header class="home-banner" >
        <div class="home-banner-bg" data-stellar-background-ratio="0.6"  "></div>
        <div class="header-home-banner">
            <!--MAINMENU AREA-->
            <div class="mainmenu-area" id="mainmenu-area">
                <div class="mainmenu-area-bg"></div>
<?php include("includes/header.php");?>
</div>
</div>
</header>
<div class="header-image" style="background: url(img/machine.jpg)no-repeat;background-size: cover;">

       
    </div>
    <div class="page-title-bar page-title-bar-breadcrumbs page-title-bar-left">
    <div class="page-title-row">
        <div class="page-title-wrapper">
            <div class="page-title-captions">
                <h1 class="entry-title" data-fontsize="20" data-lineheight="28">Python</h1>
            </div>
        
        </div>
    </div>
</div>
  <section class="index-area gray-bg sec-padding" style="padding: 50px;">
<div class="container">
    <div class="area-title text-center wow fadeIn">
                    
                        <h2>What is Python course about?</h2>
</div>
<div class="sec-db">
        <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12">
                    <div class="post-media wow bounceInLeft" style="visibility: visible; animation-name: bounceInLeft;">
                        <img src="img/avatar-004.jpg" alt="img" class="img-fluid ">
                    </div><!-- end media -->
                </div>
                <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12">
                    <div class="content">
                        <h2>Know More</h2>
                        <p>
Python is one of the most in-demand programming languages in the IT industry, along with being one of the best introductory languages for beginners.Python programming language is dominating other programming languages such as C, C++ or Java. Python is an Object-Oriented, High-Level multi-paradigm programming language with dynamic features.

Python has gained more popularity than ever. Python provides significant features which catch every programmer’s attention. Python is very simple to read and write hence, it reduces the confusion among the programmers.

Python can run smoothly on different operating systems such as Windows, Linux, Ubuntu, etc. so it can be interpreted that it is a portable language. That means if you’ve written your code for the Windows platform, you can also run it on a Mac platform.</p>

                        
                    </div>
                </div><!-- end col -->
                
                <!-- end col -->
            </div>

        </div>
    </section>
  
 <section class="service-area-three" style="padding-bottom: 80px; padding-top: 80px;">
        <div class="container">
           <!--  <div class="row">
                <div class="col-md-6 col-lg-6 col-md-offset-3 col-lg-offset-3 col-sm-12 col-xs-12">
                    <div class="area-title text-center wow fadeIn">
                        <h2>Our Courses</h2>
                      
                    </div>
                </div>
            </div> -->
            <div class="row">
                <div class="col-md-4  col-sm-4 col-xs-12">
                    <div class="single-blog wow fadeInUp" data-wow-delay="0.2s">
                       <!--  <div class="blog-image">
                            <img src="img/ai.jpg" alt="" style="width:555px; height:250px";>
                        </div> -->
                        <div class="blog-details">
                            <div class="blog-meta">
                                <a href="#" class=" text-center">Who should undergo this course</a></div>
                           
                    <ul>
                        <li>This course is for anyone who wants to learn Digital marketing
                        </li>
                        <li>Anyone who is not comfortable with coding but has skills in marketing field and knowledge of 12th standard math.</li>
                        <li>Anyone wants to start a career in Digital marketing .</li>
                    </ul>
                         </div>     <!-- <a href="#" class="read-more">Enquire</a> -->
                      
                    </div>
                </div>
              <div class="col-md-4  col-sm-4 col-xs-12">
                    <div class="single-blog wow fadeInUp" data-wow-delay="0.2s">
                       <!--  <div class="blog-image">
                            <img src="img/ai.jpg" alt="" style="width:555px; height:250px";>
                        </div> -->
                        <div class="blog-details">
                            <div class="blog-meta">
                                <a href="#" class=" text-center">Why take Digital Marketing Training?

</a></div>
                           
                    <ul>
                        <li>Digital marketing is a career that has plenty of room for techs, creatives, and business people.
                        </li>
                        <li>It’s best to focus on one or two things that you do best, then you can always learn more from there.</li>
                        <li>This is a field that’s ever-changing and engaging; there’s always something new to learn.</li>
                    </ul>
                         </div>     <!-- <a href="#" class="read-more">Enquire</a> -->
                      
                    </div>
                </div>
           
                <div class="col-md-4  col-sm-4 col-xs-12">
                    <div class="single-blog wow fadeInUp" data-wow-delay="0.2s">
                       <!--  <div class="blog-image">
                            <img src="img/ai.jpg" alt="" style="width:555px; height:250px";>
                        </div> -->
                        <div class="blog-details">
                            <div class="blog-meta">
                                <a href="#" class=" text-center">What will you learn</a></div>
                           
                    <ul>
                        <li>There are a lot of job opportunities in this field from specialization in particular domain like SEO specialist, social media manager etc.
                        </li>
                        <li>By end of the course Have an understanding of basic and advanced Digital marketing.
</li>
                        <li>Opportunities in Digital Marketing and many more you can learn.</li>
                    </ul>
                         </div>     <!-- <a href="#" class="read-more">Enquire</a> -->
                      
                    </div>
                </div>
       
            </div>
              </div>
          </section>
   
 

    <!--BLOG AREA END-->

    <!--TESTMONIAL AREA -->
    <section class="testmonial-area section-padding" id="db" style="padding-bottom: 200px;background-image: url(img/blog/training.jpg);background-attachment: fixed;background-size: cover;position: relative;
    width:100%;">
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-lg-6 col-md-offset-3 col-lg-offset-3 col-sm-12 col-xs-12">
                    <div class="area-title text-center wow fadeIn" style="color: #ffffff;">
                        <h2>what client’s say</h2>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-4 col-lg-4 col-md-offset-4 col-lg-offset-4 col-sm-8 col-sm-offset-2 col-xs-8 col-xs-offset-2">
                    <div class="client-photo-list wow fadeIn">
                        <div class="client_photo">
                            <div class="item">
                                <img src="img/testmonial/1.jpg" alt="">
                            </div>
                            <div class="item">
                                <img src="img/testmonial/2.jpg" alt="">
                            </div>
                            <div class="item">
                                <img src="img/testmonial/3.jpg" alt="">
                            </div>
                            <div class="item">
                                <img src="img/testmonial/1.jpg" alt="">
                            </div>
                            <div class="item">
                                <img src="img/testmonial/2.jpg" alt="">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="client_nav">
                        <span class="fa fa-angle-left testi_prev"></span>
                        <span class="fa fa-angle-right testi_next"></span>
                    </div>
                </div>
                <div class="col-xs-12 col-md-10 col-md-offset-1 text-center">
                    <div class="client-details-content wow fadeIn">
                        <div class="client_details">
                            <div class="item" style="color: #ffffff;">
                                <q>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. </q>
                                <h3>JABIN KANE</h3>
                                <p>CEO, TOPSMMPANEL.COM</p>
                            </div>
                            <div class="item">
                                <q>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. </q>
                                <h3>JABIN KANE</h3>
                                <p>CEO, TOPSMMPANEL.COM</p>
                            </div>
                            <div class="item">
                                <q>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. </q>
                                <h3>JABIN KANE</h3>
                                <p>CEO, TOPSMMPANEL.COM</p>
                            </div>
                            <div class="item">
                                <q>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. </q>
                                <h3>JABIN KANE</h3>
                                <p>CEO, TOPSMMPANEL.COM</p>
                            </div>
                            <div class="item">
                                <q>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. </q>
                                <h3>JABIN KANE</h3>
                                <p>CEO, TOPSMMPANEL.COM</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--TESTMONIAL AREA END -->

    <!--CLIENTS AREA-->
    
<?php include("includes/footer.php");?>

<script src="js/vendor/jquery-1.12.4.min.js"></script>
    <script src="js/vendor/bootstrap.min.js"></script>

    <!--====== PLUGINS JS ======-->
    <script src="js/vendor/jquery.easing.1.3.js"></script>
    <script src="js/vendor/jquery-migrate-1.2.1.min.js"></script>
    <script src="js/vendor/jquery.appear.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/stellar.js"></script>
    <script src="js/wow.min.js"></script>
    <script src="js/stellarnav.min.js"></script>
    <script src="js/contact-form.js"></script>
    <script src="js/jquery.sticky.js"></script>

    <!--===== ACTIVE JS=====-->
    <script src="js/main.js"></script>
    <script type="text/javascript">
        <script src="js/wow.min.js"></script>
              <script>
              new WOW().init();
              </script>
    </script>
</body>
</html>