<?php include("includes/config.php");?>

<?php include("includes/header.php");?>
  <div class="welcome-area">
            <div class="area-bg"></div>
            <div class="container">
                <div class="row flex-v-center">
                    <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                        <div class="welcome-text text-center">
                            <h2>Service</h2>
                            <ul class="page-location">
                                <li><a href="index.php">Home</a></li>
                                <li>/</li>
                                <li><a href="service.php">Service</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <!--END TOP AREA-->

    <!--SERVICE AREA-->
    <section class="service-area-two section-padding gray-bg">
         
        <div class="container">
            <div class="row">
                <div class="col-md-9 col-lg-9 col-sm-12 col-xs-12 pull-right">
                    <div class="service-details-content">
                        <h2>WEAR-HOUSE-FREIGHT</h2>
                        <div class="service-details-text">
                            <p>Having a strong distribution and warehousing strategy is critical to your success in today’s global environment. At AFP Global Logistics, we provide superior inventory and delivery services to ensure that all of our clients’ needs are met. With our professional and reliable warehouse services in Baltimore, our clients get more than just space; they get a focused warehouse solution and decades of industry expertise that will streamline their supply chain.</p>
                            <blockquote>AFP Global Logistics provides warehouse distribution services throughout the greater Washington DC metro area, including Maryland, Washington DC, and Northern VA that allow you to store your shipments in secure, climate-controlled structures.</blockquote>
                            <p>Making the choice to use a 3PL fulfillment center can drastically ease the troublesome pressures of warehousing and distribution, allowing you to focus on your core competencies. All of AFP Global Logistics solutions are customized to fit the flow of our clients’ business. Our warehouse management software (WMS) allows you to manage your inventory and shipping activity from your desktop and we can even create custom reporting to simplify all of your accounting and reporting needs.</p>
                        </div>
                        <div class="row">
                            <div class="col-md-6 col-lg-6 col-sm-12 col-xs-12">
                                <div class="faqs-left-img">
                                    <img class="about-img" src="img/about/about-details.jpg" alt="">
                                </div>
                            </div>
                            <div class="col-md-6 col-lg-6 col-sm-12 col-xs-12">
                                <div class="faqs-list">
                                    <h3>why choose carries</h3>
                                    <div class="panel-group" id="accordion">
                                        <div class="panel active">
                                            <div class="panel-heading">
                                                <h4 class="panel-title">
                                                    <a data-toggle="collapse" data-parent="#accordion" href="#faqs_one"><i class="fa fa-minus"></i> Lorem Ipsum is simply dummy text ?</a>
                                                </h4>
                                            </div>
                                            <div id="faqs_one" class="panel-collapse collapse">
                                                <div class="panel-body">Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est.</div>
                                            </div>
                                        </div>
                                        <div class="panel">
                                            <div class="panel-heading">
                                                <h4 class="panel-title">
                                                    <a data-toggle="collapse" data-parent="#accordion" href="#faqs_two"><i class="fa fa-minus"></i> Lorem Ipsum is simply dummy text ?</a>
                                                </h4>
                                            </div>
                                            <div id="faqs_two" class="panel-collapse collapse">
                                                <div class="panel-body">Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est.</div>
                                            </div>
                                        </div>
                                        <div class="panel">
                                            <div class="panel-heading">
                                                <h4 class="panel-title">
                                                    <a data-toggle="collapse" data-parent="#accordion" href="#faqs_three"><i class="fa fa-minus"></i> Lorem Ipsum is simply dummy text ?</a>
                                                </h4>
                                            </div>
                                            <div id="faqs_three" class="panel-collapse collapse">
                                                <div class="panel-body">Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est.</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-lg-3 col-sm-12 col-xs-12 pull-left">
                    <div class="service-menu">
                        <h4>Service Details</h4>
                        <ul>
                         <li><a href="road-freight.php">Road Freight <i class="fa fa-angle-right"></i></a></li>
                            <li><a href="sea-freight.php">Sea Freight <i class="fa fa-angle-right"></i></a></li>
                            <li><a href="air-freight.php">Air Freight <i class="fa fa-angle-right"></i></a></li>
                            <li><a href="wear-house.php">Wear house <i class="fa fa-angle-right"></i></a></li>
                            <li><a href="door-to-door-services.php">Door to Door Services <i class="fa fa-angle-right"></i></a></li>
                            <li><a href="custom-clearance.php">Custom Clearance Activity Freight <i class="fa fa-angle-right"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--SERVICE AREA END-->

    <!--PROMO AREA-->
    
    <!--TESTMONIAL AREA END -->
    <?php include('includes/footer.php');?>

<script src="js/vendor/jquery-1.12.4.min.js"></script>
    <script src="js/vendor/bootstrap.min.js"></script>

    <!--====== PLUGINS JS ======-->
    <script src="js/vendor/jquery.easing.1.3.js"></script>
    <script src="js/vendor/jquery-migrate-1.2.1.min.js"></script>
    <script src="js/vendor/jquery.appear.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/stellar.js"></script>
    <script src="js/wow.min.js"></script>
    <script src="js/stellarnav.min.js"></script>
    <script src="js/contact-form.js"></script>
    <script src="js/jquery.sticky.js"></script>

    <!--===== ACTIVE JS=====-->
    <script src="js/main.js"></script>
    <!--CLIENTS AREA END-->
