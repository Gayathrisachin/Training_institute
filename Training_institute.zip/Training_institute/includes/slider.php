<div class="welcome-slider-area">
            <div class="welcome-single-slide slider-bg-one">
                <div class="container">
                    <div class="row flex-v-center">
                        <div class="col-md-10 col-md-offset-1">
                            <div class="welcome-text text-center">
                                <h1><strong>Aficionado Technologies</strong></h1>
                                <p>Intense training Programs in Artificial intelligence, Cyber security, Cloud Computing, Python,
Machine learning, Digital Marketing & more.
Fresher & Corporate Training with Placements.</p>
                                <div class="home-button">
                                    <a href="#">Our Service</a>
                                    <a href="#">Get A Quate</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="welcome-single-slide slider-bg-two">
                <div class="container">
                    <div class="row flex-v-center">
                        <div class="col-md-10 col-md-offset-1">
                            <div class="welcome-text text-center">
                                <h1><strong>Aficionado Technologies</strong></h1>
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.</p>
                                <div class="home-button">
                                    <a href="#">Our Service</a>
                                    <a href="#">Get A Quate</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>