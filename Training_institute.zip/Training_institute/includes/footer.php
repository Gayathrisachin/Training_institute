<div class="footer-area dark-bg">
        <div class="footer-area-bg"></div>
        <div class="footer-top-area wow fadeIn">
            <div class="container">
                
                <div class="row">
                    <div class="col-md-12">
                        <div class="footer-border"> </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="footer-bottom-area wow fadeIn">
            <div class="container">
                <div class="row">
                    <div class="col-md-4 col-lg-4 col-sm-6 col-xs-12">
                        <div class="single-footer-widget footer-about">
                            <h3>About Us</h3>
                            <p>We are a group of young Professionals who are Enthusiast & Passionate towards enhancing Knowledge and Advancement.</p>
                            
                        </div>
                    </div>
              
                    <div class="col-md-4 col-lg-4 col-sm-6 col-xs-12">
                        <div class="single-footer-widget list-widget">
                            <h3>Information Link</h3>
                            <ul>
                                <li><a href="#">About Us</a></li>
                                <li><a href="#">Career</a></li>
                                <li><a href="#">Login</a></li>
                                <li><a href="#">Contact us</a></li>
                                
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-4 col-lg-4 col-sm-6 col-xs-12">
                        <div class="single-footer-widget instafeed-widget">
                            <h3>Contact details</h3>
                            <ul>
                                <li><a href="#">training@afitech.org</a></li>
                                <li><a href="#">www.afitech.org</a></li>
                                <li><a href="#">FAQS</a></li>
                                <li><a href="#">Srinivasa Tower, 1st floor, Btm layout, Outer Ring Rd, Opp.Reliance Fresh, Bengaluru, Karnataka 560079</a></li>
                                
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="footer-border"> </div>
                    </div>
                </div>
            </div>
        </div>
        
    </div>
    <div class="footer-copyright-area" style="background: #333333; color: #ffffff;">
            <div class="container">
                <div class="row">
                    <div class="col-md-6 col-lg-6 col-sm-12 col-xs-12">
                        <div class="footer-copyright wow fadeIn">
                            <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                            <p>Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | Lorem <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="https://fritado.com" target="_blank">Lorem</a></p>
                            <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-6 col-sm-12 col-xs-12">
                        <div class="footer-social-bookmark text-right wow fadeIn" id="social">
                            <ul class="social-bookmark">
                                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                <li><a href="#"><i class="fa fa-youtube"></i></a></li>
                                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                               
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>