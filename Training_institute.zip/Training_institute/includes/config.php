<?php
	switch ($_SERVER["SCRIPT_NAME"]) {
		case "about.php":
			$CURRENT_PAGE = "About"; 
			$PAGE_TITLE = "About Us";
			break;
		case "contact.php":
			$CURRENT_PAGE = "Contact"; 
			$PAGE_TITLE = "Contact Us";
			break;
			case "course.php":
			$CURRENT_PAGE = "Courses"; 
			$PAGE_TITLE = "Courses";
			break;
			case "register.php":
			$CURRENT_PAGE = "Register"; 
			$PAGE_TITLE = "Register";
			break;
		default:
			$CURRENT_PAGE = "Index";
			$PAGE_TITLE = "Aficionado Technologies";
	}
?>