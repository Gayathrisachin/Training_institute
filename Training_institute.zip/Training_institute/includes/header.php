

<div class="mainmenu-area" id="mainmenu-area">
                <div class="mainmenu-area-bg"></div>
 <nav class="navbar" style="margin-bottom: 0;">
                    <div class="container">
                        <div class="navbar-header">
                            <a href="index.php" class="navbar-brand"><img src="img/afitech-logo.png" alt="logo"></a>
                        </div>
                        <!-- Navbar header -->
                        <div id="main-nav" class="stellarnav">
                            <ul id="nav" class="nav navbar-nav">
                                <li><a href="index.php">home</a></li>
                                
                                       
                               <!--  <li><a href="about.php">about</a>
                                    
                                </li> -->
                                <li><a href="course.php">Course</a>
                                    <ul>
                                        <li><a href="machine.php">Machine Learning </a></li>
                                        <li><a href="digital.php">Digital Marketing</a></li>
                                        <li><a href="python.php">Python</a></li>
                                        
                                    </ul>
                                    
                                </li>
                              <!--    <li><a href="service.php">Corporate</a>
                                    <ul>
                                        <li><a href="single-service.php">Training </a></li>
                                        <li><a href="single-service.php">Hire Talent</a></li>
                                    
                                    </ul>
                                    
                                </li> -->
                                 <li><a href="#">Login</a>
                                    <ul>
                                        <li><a href="register.php">Register </a></li>
                                        <li><a href="login.php">Login</a></li>
                                        
                                    </ul>
                                    
                                </li>
                                <li><a href="career.php">Career</a>
                                <li><a href="contact.php">Contact</a>
                                    
                                </li>
                            </ul>
                        </div>
                    </div>
                </nav>
            </div>