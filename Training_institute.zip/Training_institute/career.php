<?php include("includes/config.php");?>
<!doctype html>

<html class="no-js" lang="en">

<?php include("includes/head-tag.php");?>

<body data-spy="scroll" data-target=".navbar">


    <!--- PRELOADER -->
    <div class="preeloader">
        <div class="preloader-spinner"></div>
    </div>

    <!--SCROLL TO TOP-->
    <!-- <a href="#home" class="scrolltotop"><i class="fa fa-long-arrow-up"></i></a>
 -->
    <!--START TOP AREA-->
       <header class="home-banner" >
        <div class="home-banner-bg" data-stellar-background-ratio="0.6"  "></div>
        <div class="header-home-banner">
            <!--MAINMENU AREA-->
            <div class="mainmenu-area" id="mainmenu-area">
                <div class="mainmenu-area-bg"></div>
<?php include("includes/header.php");?>
</div>
</div>
  

</header>
<div class="fullscreen-bg main">

   <img src="img/images.jpg" class="fullscreen-bg__video">
  
  <div class="loop-wrap" style="position:relative;">
   
<div class="loop-wrap" style="position:absolute;">
    <div class="mask-wrap" style="position: absolute; overflow: visible; height: auto; width: auto; ">
        <div class="caption medium_bold_white" id="parent" style="color: #000000;">LOOKING FOR CAREER OPPORTUNITIES?</div>
</div>
</div>
</div>

</div>
   <div class="page-title-bar page-title-bar-breadcrumbs page-title-bar-left">
    <div class="page-title-row">
        <div class="page-title-wrapper">
            <div class="page-title-captions">
                <h1 class="entry-title" data-fontsize="20" data-lineheight="28">Career</h1>
            </div>
        
        </div>
    </div>
</div>
<div class="container" style="margin-top: 80px; margin-bottom: 80px; border:none;background: #5d6b82;" >
<form action="https://afitech.org/Career/do_upload" enctype="multipart/form-data" method="post" accept-charset="utf-8" style="padding: 30px;">
 



<fieldset>

<!-- File Button --> 

<div class="row">
  <label class="col-md-5 control-label" for="cv">Upload Resume:</label>

  <div class="col-md-7">
    <input type="file" name="userfile" size="500"> 
    <br><br> 
         <input type="submit" value="Upload"> 
  </div>
</div><br>


<!-- Button -->


</fieldset>
</form>
 </div>
    
<?php include("includes/footer.php");?>

<script src="js/vendor/jquery-1.12.4.min.js"></script>
    <script src="js/vendor/bootstrap.min.js"></script>

    <!--====== PLUGINS JS ======-->
    <script src="js/vendor/jquery.easing.1.3.js"></script>
    <script src="js/vendor/jquery-migrate-1.2.1.min.js"></script>
    <script src="js/vendor/jquery.appear.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/stellar.js"></script>
    <script src="js/wow.min.js"></script>
    <script src="js/stellarnav.min.js"></script>
    <script src="js/contact-form.js"></script>
    <script src="js/jquery.sticky.js"></script>

    <!--===== ACTIVE JS=====-->
    <script src="js/main.js"></script>
    <script type="text/javascript">
        <script src="js/wow.min.js"></script>
              <script>
              new WOW().init();
              </script>
    </script>
   
</body>
</html>