<?php include("includes/config.php");?>
<!doctype html>

<html class="no-js" lang="en">

<?php include("includes/head-tag.php");?>

<body data-spy="scroll" data-target=".navbar">


    <!--- PRELOADER -->
    <div class="preeloader">
        <div class="preloader-spinner"></div>
    </div>

    <!--SCROLL TO TOP-->
    <!-- <a href="#home" class="scrolltotop"><i class="fa fa-long-arrow-up"></i></a>
 -->
    <!--START TOP AREA-->
       <header class="home-banner" >
        <div class="home-banner-bg" data-stellar-background-ratio="0.6"  "></div>
        <div class="header-home-banner">
            <!--MAINMENU AREA-->
            <div class="mainmenu-area" id="mainmenu-area">
                <div class="mainmenu-area-bg"></div>
<?php include("includes/header.php");?>
</div>
</div>
  

</header>
<div class="header-image" style="background: url(img/registration-netherlands.jpg)no-repeat;background-size: cover;">

       
    </div>
     <div class="page-title-bar page-title-bar-breadcrumbs page-title-bar-left">
    <div class="page-title-row">
        <div class="page-title-wrapper">
            <div class="page-title-captions">
                <h1 class="entry-title" data-fontsize="20" data-lineheight="28">Contact</h1>
            </div>
        
        </div>
    </div>
</div>
      <div class="container" style="margin-top: 80px; margin-bottom: 80px; border:none;" >
<div class="row">
   <div class="col-md-6">
   <form method="POST">
         <div class="row">
            <div class="col-md-12">
               <div class="form-group">
                  <label> Name</label>
                  <input type="text" name="name" required="" class="demo-default form-control" placeholder="First Name">
               </div>
                <div class="form-group">
                  <label>Email</label>
                  <input type="email" name="email" required="" class="demo-default form-control" placeholder="yourname@domain.com">
               </div>
                <div class="form-group">
                  <label>Mobile </label>
                  <input type="text" name="mobile" required="" class="demo-default form-control" placeholder="Mobile ">
               </div>
               <div class="form-group">
                  <label>Message</label>
                  <input type="text" name="message" required="" class="demo-default form-control" placeholder="Message">
               </div>
               
               
            </div>
         </div>
         <br>
         <div class="row">
            <div class="form-group col-md-12 text-center">
               <!--<input type="submit" class="btn btn-primary" id="myBtn" name="save_contact2" value="Submit">-->
            </div>
         </div>
     </form>
</div>
<div class="col-md-6 contact-right-info">
         <div class="map-area">
                    <h2 class="subtitle  wow fadeInDown" data-wow-duration="500ms" data-wow-delay=".3s" style="visibility: visible; ">Reach us</h2>
                   
                    <div class="map">
                        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3888.8578829062944!2d77.59905591430389!3d12.91685431957328!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bae15588b359d93%3A0xc2ed6f078ee8cd26!2sAficionado+Technologies!5e0!3m2!1sen!2sin!4v1562135495641!5m2!1sen!2sin" width="600" height="450" frameborder="0" style="border:0" allowfullscreen=""></iframe>
                        
                    </div>
                </div>
      </div>
</div>
    </div><!-- /.container -->


 
    
<?php include("includes/footer.php");?>

<script src="js/vendor/jquery-1.12.4.min.js"></script>
    <script src="js/vendor/bootstrap.min.js"></script>

    <!--====== PLUGINS JS ======-->
    <script src="js/vendor/jquery.easing.1.3.js"></script>
    <script src="js/vendor/jquery-migrate-1.2.1.min.js"></script>
    <script src="js/vendor/jquery.appear.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/stellar.js"></script>
    <script src="js/wow.min.js"></script>
    <script src="js/stellarnav.min.js"></script>
    <script src="js/contact-form.js"></script>
    <script src="js/jquery.sticky.js"></script>

    <!--===== ACTIVE JS=====-->
    <script src="js/main.js"></script>
    
        <script src="js/wow.min.js"></script>
              <script>
              new WOW().init();
              </script>
   
  
</body>
</html>