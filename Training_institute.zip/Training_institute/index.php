<?php include("includes/config.php");?>
<!doctype html>

<html class="no-js" lang="en">

<?php include("includes/head-tag.php");?>

<body data-spy="scroll" data-target=".navbar">


    <!--- PRELOADER -->
    <div class="preeloader">
        <div class="preloader-spinner"></div>
    </div>

    <!--SCROLL TO TOP-->
    <!-- <a href="#home" class="scrolltotop"><i class="fa fa-long-arrow-up"></i></a>
 -->
    <!--START TOP AREA-->
       <header class="home-banner" >
        <div class="home-banner-bg" data-stellar-background-ratio="0.6"  "></div>
        <div class="header-home-banner">
            <!--MAINMENU AREA-->
            <div class="mainmenu-area" id="mainmenu-area">
                <div class="mainmenu-area-bg"></div>
<?php include("includes/header.php");?>
</div>
</div>
  
 <?php include("includes/slider.php");?>
</header>

   <section class="index-area gray-bg ">
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-lg-6 col-md-offset-3 col-lg-offset-3 col-sm-12 col-xs-12">
                    <div class="area-title text-center wow fadeIn">
                        <h2>ABout Us</h2>
                        
                    </div>
                </div>
            </div>
            <div class="row ">
                <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12">
                    <div class="content">
                        <h4>2018 BEST Training Institute</h4>
                        <h2>Welcome to Aficionado Technologies</h2>
                        
                        <p>Comprehensive course structure to suit the Industry/Project requirements. Highly experienced Trainers and Certified Instructors in Global technologies from all over the world, who work on live projects. We have a team of SMEs to research, test, analyze, experiment for developing &amp; designing unique training programs and contents. We are the Only One to provide customized advanced global trainings to individuals, based on Industry &amp; Project needs. </p>

                        
                    </div><!-- end messagebox -->
                </div><!-- end col -->
                
                <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12">
                    <div class="post-media wow bounceInRight" style="visibility: visible; animation-name: fadeIn;">
                        <img src="img/about_02.jpg" alt="img" class="img-fluid ">
                    </div><!-- end media -->
                </div><!-- end col -->
            </div>
        </div>
    </section>


 <section class="index-area gray-bg sec-padding" style="padding: 50px 0;">
<div class="container">
    <div class="row">

        <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12">
                    <div class="post-media wow bounceInLeft" style="visibility: visible; animation-name: bounceInLeft;">
                        <img src="img/about_02.jpg" alt="img" class="img-fluid ">
                    </div><!-- end media -->
                </div>
                <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12">
                    <div class="content">
                        
                        <h2>WE BELIEVE IN INNOVATIVE IDEAS</h2>
                        <p>We are the only Company in India to provide detailed Career Counselling, blending 50 parameters to measure, calculate, test, analyze & then advice the Best Career Options for every individual.</p>
<p>Over the years, we have trained over 2000 batches globally, with a record of 100% employment to its alumni, majorly with Top 100 MNCs.</p>

                        
                    </div>
                </div><!-- end col -->
                
                <!-- end col -->
            </div>

        </div>
    </section>
  

 <section class="service-area-three ">
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-lg-6 col-md-offset-3 col-lg-offset-3 col-sm-12 col-xs-12">
                    <div class="area-title text-center wow fadeIn">
                        <h2>Our Courses</h2>
                        <p>We are always beside you to support whenever you need us for endless Learning.
We offer the following Courses : </p>
                    </div>
                </div>
            </div>

  <div class="flip-box-wrapper">   
        <div class="container" style="padding-right: 0px;">
          <div class="row" style="margin-right: 0;">
        <div class="col-md-6 col-lg-6 col-sm-4 col-xs-12">
  <div class="flip-box">
  <div class="flip-box-inner">
    <div class="flip-box-front">
      <div class="flip-box-front-inner" style="margin-top:120px;">
        <h2 class="flip-box-heading" style="color:#efefef;" data-fontsize="26" data-lineheight="34">Machine Learning</h2></div>
    </div>
    <div class="flip-box-back">
 
    <div class="flip-box-back-inner" style="margin-top: 60px;">
        <!-- <h3>Machine Learning</h3> -->
        <div class="flip-box-column-wrppaer">
        <div class="flip-box-column-table">
            <div class="column-tablecell">
      <p>Machine Learning is the top trending and most sought-after IT course in India Afitech has designed the best Machine Learning training in Bangalore with the complete syllabus</p>
    </div>
  </div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="col-md-6 col-lg-6 col-sm-4 col-xs-12">
<div class="flip-box">
  <div class="flip-box-inner">
    <div class="flip-box-front">
      <div class="flip-box-front-inner" style="margin-top:120px;">
        <h2 class="flip-box-heading" style="color:#efefef;" data-fontsize="26" data-lineheight="34">Digital Marketing</h2></div>
    </div>
    <div class="flip-box-back">
 
    <div class="flip-box-back-inner" style="margin-top:60px;">
        <!-- <h3>Digital Marketing
</h3> -->
        <div class="flip-box-column-wrppaer">
        <div class="flip-box-column-table">
            <div class="column-tablecell">
      <p>Digital Marketing will remain as the most powerful way of Marketing in the future. But as the dynamics of digital marketing a digital marketer has to be smart and adapt to latest changes.</p>
    </div>
  </div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="col-md-6 col-lg-6 col-sm-4 col-xs-12">
<div class="flip-box">
  <div class="flip-box-inner">
    <div class="flip-box-front">
      <div class="flip-box-front-inner" style="margin-top:120px;">
        <h2 class="flip-box-heading" style="color:#efefef;" data-fontsize="26" data-lineheight="34">Python</h2></div>
    </div>
    <div class="flip-box-back">
 
    <div class="flip-box-back-inner" style="margin-top: 60px;">
      <!--   <h3>Python</h3> -->
        <div class="flip-box-column-wrppaer">
        <div class="flip-box-column-table">
            <div class="column-tablecell">
      <p>Python is one of the most in-demand programming languages in the IT industry, along with being one of the best introductory languages for beginners.
</p>
    </div>
  </div>
</div>
</div>
</div>
</div>
</div>
</div>
 <div class="col-md-6 col-lg-6 col-sm-4 col-xs-12">
<div class="flip-box">
  <div class="flip-box-inner">
    <div class="flip-box-front">
      <div class="flip-box-front-inner" style="margin-top: 120px;">
        <h2 class="flip-box-heading" style="color:#efefef;" data-fontsize="26" data-lineheight="34">Data Science
</h2></div>
    </div>
    <div class="flip-box-back">
 
    <div class="flip-box-back-inner" style="margin-top: 60px;">
        <!-- <h3>Data Science</h3> -->
        <div class="flip-box-column-wrppaer">
        <div class="flip-box-column-table">
            <div class="column-tablecell">
      <p>Data Science has been named as the sexiest practice in the IT field. Every success story of a Company to every advanceAI algorithm uses Data Science discipline to advance. 
</p>
    </div>
  </div>
</div>
</div>
</div>
</div>
</div>
</div>
 <div class="col-md-6 col-lg-6 col-sm-4 col-xs-12">
<div class="flip-box">
  <div class="flip-box-inner">
    <div class="flip-box-front">
      <div class="flip-box-front-inner" style="margin-top: 120px;">
        <h2 class="flip-box-heading" style="color:#efefef;" data-fontsize="26" data-lineheight="34">AWS
</h2></div>
    </div>
    <div class="flip-box-back">
 
    <div class="flip-box-back-inner" style="margin-top: 60px;">
      <!--   <h3>AWS</h3> -->
        <div class="flip-box-column-wrppaer">
        <div class="flip-box-column-table">
            <div class="column-tablecell">
      <p>Afitech presents a unique syllabus for AWS where you will get trained both as AWS administrator or AWS developer to give wider career choice.
</p>
    </div>
  </div>
</div>
</div>
</div>
</div>
</div>
</div>
 <div class="col-md-6 col-lg-6 col-sm-4 col-xs-12">
<div class="flip-box">
  <div class="flip-box-inner">
    <div class="flip-box-front">
      <div class="flip-box-front-inner" style="margin-top:120px;">
       <h2 class="flip-box-heading" style="color:#efefef;" data-fontsize="26" data-lineheight="34">Devops
</h2></div>
    </div>
    <div class="flip-box-back">
 
    <div class="flip-box-back-inner" style="margin-top: 60px;">
       <!--  <h3>DevOps </h3> -->
        <div class="flip-box-column-wrppaer">
        <div class="flip-box-column-table">
            <div class="column-tablecell">
      <p>DevOps is a set of practices that automates the processes between software development and IT teams, in order that they can build, test, and release software faster and more reliably. 
</p>
    </div>
  </div>
</div>
</div>
</div>
</div>
</div>
</div>
 <div class="col-md-6 col-lg-6 col-sm-4 col-xs-12">
<div class="flip-box">
  <div class="flip-box-inner">
    <div class="flip-box-front">
      <div class="flip-box-front-inner" style="margin-top:120px;">
       <h2 class="flip-box-heading" style="color:#efefef;" data-fontsize="26" data-lineheight="34">Cyber Security
</h2></div>
    </div>
    <div class="flip-box-back">
 
    <div class="flip-box-back-inner" style="margin-top: 60px;">
       <!--  <h3>Cyber Security</h3> -->
        <div class="flip-box-column-wrppaer">
        <div class="flip-box-column-table">
            <div class="column-tablecell">
      <p>Cyber Security is a discipline to design a technology or a security algorithm to defend a computer system, network, user data or a software from unauthorized access.
</p>
    </div>
  </div>
</div>
</div>
</div>
</div>
</div>
</div>
 <div class="col-md-6 col-lg-6 col-sm-4 col-xs-12">
<div class="flip-box">
  <div class="flip-box-inner">
    <div class="flip-box-front">
      <div class="flip-box-front-inner" style="margin-top:120px;">
        <h2 class="flip-box-heading" style="color:#efefef;" data-fontsize="26" data-lineheight="34"> Mulesoft
</h2></div>
    </div>
    <div class="flip-box-back">
 
    <div class="flip-box-back-inner" style="margin-top:60px;">
   <!--      <h3>Mulesoft</h3> -->
        <div class="flip-box-column-wrppaer">
        <div class="flip-box-column-table">
            <div class="column-tablecell">
      <p>Being a new booming technology in the market it is very hard to find proper MuleSoft Anypoint training in India. Afitech MuleSoft training fills this gap with full classroom training. 
</p>
    </div>
  </div>
</div>
</div>
</div>
</div>
</div>
</div>
   </div> 
</div>
   </div>
</div>
</section>




    
    <!--PROMO AREA END-->

    <!--BLOG AREA-->
   <section class="service-area-three" style="padding-bottom: 30px;">
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-lg-6 col-md-offset-3 col-lg-offset-3 col-sm-12 col-xs-12">
                    <div class="area-title text-center wow fadeIn">
                        <h2>Training Method</h2>
                      
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-4 col-lg-4 col-sm-6 col-xs-12">
                    <div class="single-blog wow fadeInUp" data-wow-delay="0.2s">
                       <!--  <div class="blog-image">
                            <img src="img/blog/img1_spc.jpg" alt="">
                        </div> -->
                        <div class="blog-details text-center">
                            <div class="blog-meta"><a href="#"><i class="fa fa-home"></i></a></div>
                            <h3><a href="#">
                            Unique method of training</a></h3>
                            <p>We have certain researched designed unique approach for trainings.

ENQUIRY</p>
                            <a href="#" class="read-more">Enquire</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-lg-4 col-sm-6 col-xs-12">
                    <div class="single-blog wow fadeInUp" data-wow-delay="0.3s">
                      <!--   <div class="blog-image">
                            <img src="img/blog/training.jpg" alt="">
                        </div> -->
                        <div class="blog-details text-center">
                            <div class="blog-meta"><a href="#"><i class="fa fa-handshake-o" aria-hidden="true"></i></a></div>
                            <h3><a href="air-freight.php">Fully Hands-on Training</a></h3>
                            <p>Our training programs are designed as 95% hands-on & 5% Practical Projects.</p>
                            <a href="#" class="read-more">Enquire</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-lg-4 col-sm-12 col-xs-12">
                    <div class="single-blog wow fadeInUp" data-wow-delay="0.4s">
                        <!-- <div class="blog-image">
                            <img src="img/blog/blog_3.jpg" alt="">
                        </div> -->
                        <div class="blog-details text-center">
                            <div class="blog-meta"><a href="#"><i class="fa fa-clock-o"></i></a></div>
                            <h3><a href="road-freight.php">Flexible Timings and Location</a></h3>
                            <p>Learn from anywhere anytime as per your convenience in just a click.</p>
                            <a href="#" class="read-more">Enquire</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


 <section class="service-area-three" style="padding-bottom: 80px;">
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-lg-6 col-md-offset-3 col-lg-offset-3 col-sm-12 col-xs-12">
                    <div class="area-title text-center wow fadeIn">
                        <h2>Placements</h2>
                      
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-4 col-lg-4 col-sm-6 col-xs-12">
                    <div class="single-blog wow fadeInUp" data-wow-delay="0.2s">
                       <!--  <div class="blog-image">
                            <img src="img/blog/img1_spc.jpg" alt="">
                        </div> -->
                        <div class="blog-details text-center">
                            <div class="blog-meta"><a href="#"><i class="fa fa-money"></i></a></div>
                            <h3><a href="#">
                            Affordable fees</a></h3>
                            <p>Effective Quality training, Uniquely customized and designed at an affordable fees.

ENQUIRY</p>
                            <a href="#" class="read-more">Enquire</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-lg-4 col-sm-6 col-xs-12">
                    <div class="single-blog wow fadeInUp" data-wow-delay="0.3s">
                      <!--   <div class="blog-image">
                            <img src="img/blog/training.jpg" alt="">
                        </div> -->
                        <div class="blog-details text-center">
                            <div class="blog-meta"><a href="#"><i class="fa fa-lightbulb-o" aria-hidden="true"></i></a></div>
                            <h3><a href="air-freight.php">INTERVIEW PREPARATION</a></h3>
                            <p>We have a dedicated team of experts to train every individual for interviews.</p>
                            <a href="#" class="read-more">Enquire</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-lg-4 col-sm-12 col-xs-12">
                    <div class="single-blog wow fadeInUp" data-wow-delay="0.4s">
                        <!-- <div class="blog-image">
                            <img src="img/blog/blog_3.jpg" alt="">
                        </div> -->
                        <div class="blog-details text-center">
                            <div class="blog-meta"><a href="#"><i class="fa fa-globe"></i></a></div>
                            <h3><a href="road-freight.php"> LEARN FROM GLOBAL LEADERS</a></h3>
                            <p>Learn from Industry Experts located at different continents of the world.</p>
                            <a href="#" class="read-more">Enquire</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!--BLOG AREA END-->

    <!--TESTMONIAL AREA -->
    <section class="testmonial-area section-padding" id="db" style="padding-bottom: 200px;padding-top:0;background-image: url(img/blog/training.jpg);background-attachment: fixed;background-size: cover;position: relative;
    width:100%;">
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-lg-6 col-md-offset-3 col-lg-offset-3 col-sm-12 col-xs-12">
                    <div class="area-title text-center wow fadeIn" style="color: #ffffff;">
                        <h2>what client’s say</h2>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-4 col-lg-4 col-md-offset-4 col-lg-offset-4 col-sm-8 col-sm-offset-2 col-xs-8 col-xs-offset-2">
                    <div class="client-photo-list wow fadeIn">
                        <div class="client_photo">
                            <div class="item">
                                <img src="img/testmonial/1.jpg" alt="">
                            </div>
                            <div class="item">
                                <img src="img/testmonial/2.jpg" alt="">
                            </div>
                            <div class="item">
                                <img src="img/testmonial/3.jpg" alt="">
                            </div>
                            <div class="item">
                                <img src="img/testmonial/1.jpg" alt="">
                            </div>
                            <div class="item">
                                <img src="img/testmonial/2.jpg" alt="">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="client_nav">
                        <span class="fa fa-angle-left testi_prev"></span>
                        <span class="fa fa-angle-right testi_next"></span>
                    </div>
                </div>
                <div class="col-xs-12 col-md-10 col-md-offset-1 text-center">
                    <div class="client-details-content wow fadeIn">
                        <div class="client_details">
                            <div class="item" style="color: #ffffff;">
                                <q>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. </q>
                                <h3>JABIN KANE</h3>
                                <p>CEO, TOPSMMPANEL.COM</p>
                            </div>
                            <div class="item">
                                <q>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. </q>
                                <h3>JABIN KANE</h3>
                                <p>CEO, TOPSMMPANEL.COM</p>
                            </div>
                            <div class="item">
                                <q>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. </q>
                                <h3>JABIN KANE</h3>
                                <p>CEO, TOPSMMPANEL.COM</p>
                            </div>
                            <div class="item">
                                <q>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. </q>
                                <h3>JABIN KANE</h3>
                                <p>CEO, TOPSMMPANEL.COM</p>
                            </div>
                            <div class="item">
                                <q>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. </q>
                                <h3>JABIN KANE</h3>
                                <p>CEO, TOPSMMPANEL.COM</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--TESTMONIAL AREA END -->

    <!--CLIENTS AREA-->
    
<?php include("includes/footer.php");?>

<script src="js/vendor/jquery-1.12.4.min.js"></script>
    <script src="js/vendor/bootstrap.min.js"></script>

    <!--====== PLUGINS JS ======-->
    <script src="js/vendor/jquery.easing.1.3.js"></script>
    <script src="js/vendor/jquery-migrate-1.2.1.min.js"></script>
    <script src="js/vendor/jquery.appear.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/stellar.js"></script>
    <script src="js/wow.min.js"></script>
    <script src="js/stellarnav.min.js"></script>
    <script src="js/contact-form.js"></script>
    <script src="js/jquery.sticky.js"></script>

    <!--===== ACTIVE JS=====-->
    <script src="js/main.js"></script>
    <script type="text/javascript">
        <script src="js/wow.min.js"></script>
              <script>
              new WOW().init();
              </script>
    </script>
</body>
</html>